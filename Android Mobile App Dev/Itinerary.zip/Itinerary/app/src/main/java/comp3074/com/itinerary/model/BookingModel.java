package comp3074.com.itinerary.model;

/**
 * Created by Mehdi on 12/21/2017.
 */

public class BookingModel
{
    private int ItineraryId;
private int id;

    public BookingModel(int itineraryId) {
        ItineraryId = itineraryId;
    }

    public BookingModel() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getItineraryId() {

        return ItineraryId;
    }

    public void setItineraryId(int itineraryId) {
        ItineraryId = itineraryId;
    }
}
