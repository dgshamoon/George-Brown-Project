package comp3074.com.itinerary;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import comp3074.com.itinerary.data.SqlHelper;
import comp3074.com.itinerary.model.BookingModel;
import comp3074.com.itinerary.model.ItineraryModel;

public class MainActivity extends AppCompatActivity {
    ArrayAdapter<ItineraryModel> adapter;
    List<ItineraryModel> itineraryModels;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView = (ListView) findViewById(R.id.bookingList);
        fillBooking();
        adapter = new ArrayAdapter<ItineraryModel>(MainActivity.this, android.R.layout.simple_list_item_1, android.R.id.text1, itineraryModels);
        listView.setAdapter(adapter);
    }

    private void fillBooking() {
        SqlHelper helper = new SqlHelper(getApplicationContext());
        List<BookingModel> bookings = helper.getBookings();
        if (itineraryModels != null) {
            int size = itineraryModels.size();
            for (int i = 0; i < size; i++)
                itineraryModels.remove(0);
        }else
            itineraryModels=new ArrayList<>();
        for (BookingModel model : bookings) {
            ItineraryModel itineraryById = helper.getItineraryById(model.getItineraryId());
            if (itineraryById != null) {
                itineraryModels.add(itineraryById);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.addBookingItem:
                startActivityForResult(new Intent(MainActivity.this, Main2Activity.class), 100);
                break;
            case R.id.viewPersonalInfoItem:
                startActivity(new Intent(MainActivity.this, PersonalInfoActivity.class));
                break;
         
            case R.id.sdfsdf:
                new SqlHelper(getApplicationContext()).clearBooking();
                fillBooking();
                adapter.notifyDataSetChanged();
                break;

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK) {
            fillBooking();
            adapter.notifyDataSetChanged();
        }
    }
}
