    package comp3074.com.itinerary;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import comp3074.com.itinerary.data.SqlHelper;
import comp3074.com.itinerary.model.PersonalInformationModel;

    public class PersonalInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_info);
        setTitle("Personal information");
        Button personalInfoBtn= (Button) findViewById(R.id.personalInfoBtn);
        final EditText nameText= (EditText) findViewById(R.id.nameText);
        final EditText addressText= (EditText) findViewById(R.id.addressText);
        final EditText phoneText= (EditText) findViewById(R.id.phoneText);
        final EditText cardText= (EditText) findViewById(R.id.cardText);
        final SqlHelper helper=new SqlHelper(getApplicationContext());
        PersonalInformationModel personalInfo1 = helper.getPersonalInfo();
        nameText.setText(personalInfo1.getName());
        addressText.setText(personalInfo1.getAddress());
        phoneText.setText(personalInfo1.getPhoneNumber());
        cardText.setText(personalInfo1.getCreditCardNumber());
        personalInfoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PersonalInformationModel model=new PersonalInformationModel();
                model.setName(nameText.getText().toString());
                model.setAddress(addressText.getText().toString());
                model.setPhoneNumber(phoneText.getText().toString());
                model.setCreditCardNumber(cardText.getText().toString());
                helper.addPersonalInfo(model);
                finish();
            }
        });
    }
}
