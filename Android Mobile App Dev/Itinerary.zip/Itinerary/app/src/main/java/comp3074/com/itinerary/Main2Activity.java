package comp3074.com.itinerary;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import comp3074.com.itinerary.data.SqlHelper;
import comp3074.com.itinerary.model.BookingModel;
import comp3074.com.itinerary.model.ItineraryModel;

public class Main2Activity extends AppCompatActivity {
    ListView listView;
    List<ItineraryModel> itineraryModels;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        listView = (ListView) findViewById(R.id.searchResultList);
        final DatePicker datePicker = (DatePicker) findViewById(R.id.datePicker);
        Button searchByDateButton = (Button) findViewById(R.id.searchByDateBtn);
        final SqlHelper helper = new SqlHelper(getApplicationContext());
        itineraryModels = helper.getItinerariesOrderByCost();
        final ArrayAdapter<ItineraryModel> adapter = new ArrayAdapter<ItineraryModel>(Main2Activity.this, android.R.layout.simple_list_item_1, android.R.id.text1, itineraryModels);
        listView.setAdapter(adapter);
        registerForContextMenu(listView);
        searchByDateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int year = datePicker.getYear();
                int month = datePicker.getMonth()+1;
                int day = datePicker.getDayOfMonth();
                int size = itineraryModels.size();
                for (int i = 0; i < size; i++) {
                    itineraryModels.remove(0);
                }

                List<ItineraryModel> modelList = helper.getItinerariesOrderByCost();
                for (ItineraryModel model:modelList){
                    if(model.getDepartureYear()==year && model.getDepartureMonth()==month && model.getDepartureDay()==day){
                        itineraryModels.add(model);
                    }
                }
//                itineraryModels=modelList;
                adapter.notifyDataSetChanged();

            }
        });
        final EditText originSearchEdit = (EditText) findViewById(R.id.originSearchText);
        final EditText destinationSearchEdit = (EditText) findViewById(R.id.detinationSearchText);
        Button searchbyOriginDestinationBtn = (Button) findViewById(R.id.searchByOriginDestinationBtn);
        searchbyOriginDestinationBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                List<ItineraryModel> list = helper.getItinerariesOrderByCost();
                int size = itineraryModels.size();
                for (int i = 0; i < size; i++) {
                    itineraryModels.remove(0);
                }
                for (ItineraryModel model:list){
                    if(model.getOrigin().equalsIgnoreCase(originSearchEdit.getText().toString())&& model.getDestination().equalsIgnoreCase(destinationSearchEdit.getText().toString()))
                        itineraryModels.add(model);
                }
//                itineraryModels.addAll(list);
                adapter.notifyDataSetChanged();
            }
        });

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.setHeaderTitle("Select Action");
        menu.add(0, 1001, 0, "Book this item");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        if (item.getTitle() == "Book this item") {
            AdapterView.AdapterContextMenuInfo info= (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
            int selectedItemPosition =info.position;
            ItineraryModel model = itineraryModels.get(selectedItemPosition);
            if(model!=null){
                if(new SqlHelper(getApplicationContext()).addBooking(new BookingModel(model.getId()))){
                    Toast.makeText(this, "Booked", Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                }
            }
        }
        return super.onContextItemSelected(item);
    }
}
