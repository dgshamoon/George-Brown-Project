package comp3074.com.itinerary.model;

import java.util.Date;


public class ItineraryModel {
    private int id;
    private int flightNumber;
    private int departureYear;
    private int departureMonth;
    private int departureDay;
    private int departureHour;
    private int departureMinute;
    private int arrivalYear;
    private int arrivalMonth;
    private int arrivalDay;
    private int arrivalHour;
    private int arrivalMinute;
    private String airline;
    private String origin;
    private String destination;
    private double cost;
    private int travelHour;
    private int travelMinute;

    @Override
    public String toString() {
        StringBuilder builder=new StringBuilder();
        builder.append("Origin: ");
        builder.append(origin);
        builder.append(" & ");
        builder.append("Destination: ");
        builder.append(destination);
        builder.append("\n");
        builder.append("Departure: ");
        builder.append(departureYear);
        builder.append("/");
        builder.append(departureMonth);
        builder.append("/");
        builder.append(departureDay);
        builder.append(" ");
        builder.append(departureHour);
        builder.append(":");
        builder.append(departureMinute);
        builder.append(" & Arrival: ");
        builder.append(arrivalYear);
        builder.append("/");
        builder.append(arrivalMonth);
        builder.append("/");
        builder.append(arrivalDay);
        builder.append(" ");
        builder.append(arrivalHour);
        builder.append(":");
        builder.append(arrivalMinute);
        builder.append("\nAirline: ");
        builder.append(airline);
        builder.append(" & cost: ");
        builder.append(cost);
        builder.append("\n Travelling Time: ");
        builder.append(travelHour);
        builder.append(":");
        builder.append(travelMinute);
        return builder.toString();
//        return String.format("Origin: %s & Destination: %s\nDeparture: %d/%d/%d %d:%d & Arrival: %d/%d/%d %d:%d\nAirline: %s & cost: %d\n Travelling Time: %d:%d",
//                origin,destination,departureYear,departureMonth,departureDay,departureHour,departureMinute,arrivalYear,arrivalMonth,arrivalDay,
//                arrivalHour,arrivalMinute,airline,cost,travelHour,travelMinute);
    }

    public int getDepartureHour() {
        return departureHour;
    }

    public void setDepartureHour(int departureHour) {
        this.departureHour = departureHour;
    }

    public int getDepartureMinute() {
        return departureMinute;
    }

    public void setDepartureMinute(int departureMinute) {
        this.departureMinute = departureMinute;
    }

    public int getArrivalHour() {
        return arrivalHour;
    }

    public void setArrivalHour(int arrivalHour) {
        this.arrivalHour = arrivalHour;
    }

    public int getArrivalMinute() {
        return arrivalMinute;
    }

    public void setArrivalMinute(int arrivalMinute) {
        this.arrivalMinute = arrivalMinute;
    }

    public int getDepartureYear() {
        return departureYear;
    }

    public void setDepartureYear(int departureYear) {
        this.departureYear = departureYear;
    }

    public int getDepartureMonth() {
        return departureMonth;
    }

    public void setDepartureMonth(int departureMonth) {
        this.departureMonth = departureMonth;
    }

    public int getDepartureDay() {
        return departureDay;
    }

    public void setDepartureDay(int departureDay) {
        this.departureDay = departureDay;
    }

    public int getArrivalYear() {
        return arrivalYear;
    }

    public void setArrivalYear(int arrivalYear) {
        this.arrivalYear = arrivalYear;
    }

    public int getArrivalMonth() {
        return arrivalMonth;
    }

    public void setArrivalMonth(int arrivalMonth) {
        this.arrivalMonth = arrivalMonth;
    }

    public int getArrivalDay() {
        return arrivalDay;
    }

    public void setArrivalDay(int arrivalDay) {
        this.arrivalDay = arrivalDay;
    }

    public int getTravelHour() {
        return travelHour;
    }

    public void setTravelHour(int travelHour) {
        this.travelHour = travelHour;
    }

    public int getTravelMinute() {
        return travelMinute;
    }

    public void setTravelMinute(int travelMinute) {
        this.travelMinute = travelMinute;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(int flightNumber) {
        this.flightNumber = flightNumber;
    }


    public String getAirline() {
        return airline;
    }

    public void setAirline(String airline) {
        this.airline = airline;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }


}
