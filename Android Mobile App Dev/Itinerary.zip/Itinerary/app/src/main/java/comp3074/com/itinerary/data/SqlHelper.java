package comp3074.com.itinerary.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

import comp3074.com.itinerary.model.BookingModel;
import comp3074.com.itinerary.model.ItineraryModel;
import comp3074.com.itinerary.model.PersonalInformationModel;

public class SqlHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "ItineraryDb";

    public SqlHelper(Context context) {
        super(context, DB_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "create table if not exists Itinerary(" +
                "id INTEGER primary key autoincrement," +
                "flightNumber integer," +
                "departureYear integer," +
                "departureMonth integer," +
                "departureDay integer," +
                "departureHour integer," +
                "departureMinute integer," +
                "arrivalYear integer," +
                "arrivalMonth integer," +
                "arrivalDay integer," +
                "arrivalHour integer," +
                "arrivalMinute integer," +
                "airline text," +
                "origin text," +
                "destination  text," +
                "cost  real," +
                "travellingHour  integer," +
                "travellingMinute  integer " +

                ");";
        db.execSQL(query);
        query = "insert into Itinerary(flightNumber,departureYear,departureMonth,departureDay,departureHour,departureMinute,arrivalYear,arrivalMonth,arrivalDay," +
                "arrivalHour,arrivalMinute,airline,origin,destination,cost,travellingHour,travellingMinute) values" +
                "(342,2017,12,21,12,30,2017,12,22,13,45,'Us Air','New York','Hong kong',2100,24,10)";
        db.execSQL(query);
        query = "insert into Itinerary(flightNumber,departureYear,departureMonth,departureDay,departureHour,departureMinute,arrivalYear,arrivalMonth,arrivalDay," +
                "arrivalHour,arrivalMinute,airline,origin,destination,cost,travellingHour,travellingMinute) values" +
                "(562,2017,12,25,18,30,2017,12,25,22,45,'Canada Airline','New York','Chicago',800,24,10)";
        db.execSQL(query);
        query = "insert into Itinerary(flightNumber,departureYear,departureMonth,departureDay,departureHour,departureMinute,arrivalYear,arrivalMonth,arrivalDay," +
                "arrivalHour,arrivalMinute,airline,origin,destination,cost,travellingHour,travellingMinute) values" +
                "(102,2017,12,28,2,30,2017,12,29,13,45,'Us Air','New York','Hong kong',2100,24,10)";
        db.execSQL(query);
        query = "insert into Itinerary(flightNumber,departureYear,departureMonth,departureDay,departureHour,departureMinute,arrivalYear,arrivalMonth,arrivalDay," +
                "arrivalHour,arrivalMinute,airline,origin,destination,cost,travellingHour,travellingMinute) values" +
                "(32,2017,12,28,12,30,2017,12,28,18,45,'Us Air','New York','Washington',120,4,0)";
        db.execSQL(query);
        query = "insert into Itinerary(flightNumber,departureYear,departureMonth,departureDay,departureHour,departureMinute,arrivalYear,arrivalMonth,arrivalDay," +
                "arrivalHour,arrivalMinute,airline,origin,destination,cost,travellingHour,travellingMinute) " +
                "values(222,2018,1,10,12,30,2018,1,11,13,45,'Good airline','Toronto','chicago',150,12,10)";
        db.execSQL(query);
        query = "insert into Itinerary(flightNumber,departureYear,departureMonth,departureDay,departureHour,departureMinute,arrivalYear,arrivalMonth,arrivalDay," +
                "arrivalHour,arrivalMinute,airline,origin,destination,cost,travellingHour,travellingMinute) values" +
                "(342,2018,1,21,12,30,2018,1,22,13,45,'Us Air','New York','Hong kong',2100,24,10)";
        db.execSQL(query);
        query = "insert into Itinerary(flightNumber,departureYear,departureMonth,departureDay,departureHour,departureMinute,arrivalYear,arrivalMonth,arrivalDay," +
                "arrivalHour,arrivalMinute,airline,origin,destination,cost,travellingHour,travellingMinute) values" +
                "(354,2018,1,26,12,30,2018,1,26,12,45,'Us Air','chicago','Hong kong',2100,24,10)";
        db.execSQL(query);
        query = "create table if not exists Booking(" +
                "id INTEGER primary key autoincrement," +
                "ItineraryId integer," +
                "foreign key(ItineraryId) references Itinerary(id)" +

                ");";
        db.execSQL(query);
        query = "create table if not exists PersonalInformation(" +
                "id INTEGER primary key autoincrement," +
                "name text," +
                "address text," +
                "phoneNumber text," +
                "creditCardNumber text" +
                ");";
        db.execSQL(query);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean addItineraryModel(ItineraryModel model) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("flightNumber", model.getFlightNumber());
        values.put("departureYear", model.getDepartureYear());
        values.put("departureMonth", model.getDepartureMonth());
        values.put("departureDay", model.getDepartureDay());
        values.put("departureHour", model.getDepartureHour());
        values.put("departureMinute", model.getDepartureMinute());
        values.put("arrivalYear", model.getArrivalYear());
        values.put("arrivalMonth", model.getArrivalMonth());
        values.put("arrivalDay", model.getArrivalDay());
        values.put("arrivalHour", model.getArrivalHour());
        values.put("arrivalMinute", model.getArrivalMinute());
        values.put("airline", model.getAirline());
        values.put("origin", model.getOrigin());
        values.put("destination", model.getDestination());
        values.put("cost", model.getCost());
        values.put("travellingHour", model.getTravelHour());
        values.put("travellingMinute", model.getTravelMinute());
        boolean result = database.insert("Itinerary", null, values) > 0;

        return result;
    }

    public List<ItineraryModel> getItinerariesByOriginDestination(String origin, String destination) {
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.query("Itinerary", new String[]{"id", "flightNumber", "departureYear", "departureMonth", "departureDay",
                "departureHour", "departureMinute", "arrivalYear", "arrivalMonth", "arrivalDay", "arrivalHour", "arrivalMinute", "airline", "origin",
                "destination", "cost", "travellingHour", "travellingMinute"}, "origin=? and destination=?", new String[]{origin, destination}, null, null, "cost");
        List<ItineraryModel> itineraryModels = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                ItineraryModel model = new ItineraryModel();
                model.setId(cursor.getInt(cursor.getColumnIndex("id")));
                model.setFlightNumber(cursor.getInt(cursor.getColumnIndex("flightNumber")));
                model.setDepartureYear(cursor.getInt(cursor.getColumnIndex("departureYear")));
                model.setDepartureMonth(cursor.getInt(cursor.getColumnIndex("departureMonth")));
                model.setDepartureDay(cursor.getInt(cursor.getColumnIndex("departureDay")));
                model.setDepartureHour(cursor.getInt(cursor.getColumnIndex("departureHour")));
                model.setDepartureMinute(cursor.getInt(cursor.getColumnIndex("departureMinute")));
                model.setArrivalYear(cursor.getInt(cursor.getColumnIndex("arrivalYear")));
                model.setArrivalMonth(cursor.getInt(cursor.getColumnIndex("arrivalMonth")));
                model.setArrivalDay(cursor.getInt(cursor.getColumnIndex("arrivalDay")));
                model.setArrivalHour(cursor.getInt(cursor.getColumnIndex("arrivalHour")));
                model.setArrivalMinute(cursor.getInt(cursor.getColumnIndex("arrivalMinute")));
                model.setAirline(cursor.getString(cursor.getColumnIndex("airline")));
                model.setOrigin(cursor.getString(cursor.getColumnIndex("origin")));
                model.setDestination(cursor.getString(cursor.getColumnIndex("destination")));
                model.setCost(cursor.getDouble(cursor.getColumnIndex("cost")));
                model.setTravelHour(cursor.getInt(cursor.getColumnIndex("travellingHour")));
                model.setTravelMinute(cursor.getInt(cursor.getColumnIndex("travellingMinute")));
                itineraryModels.add(model);
            } while (cursor.moveToNext());
            return itineraryModels;
        }
        return null;
    }

    public List<ItineraryModel> getItinerariesByDepartureDateOrderbyCost(int year, int month, int day) {
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.query("Itinerary", new String[]{"id", "flightNumber", "departureYear", "departureMonth", "departureDay",
                "departureHour", "departureMinute", "arrivalYear", "arrivalMonth", "arrivalDay", "arrivalHour", "arrivalMinute", "airline", "origin",
                "destination", "cost", "travellingHour", "travellingMinute"}, "departureYear=? and departureMonth=? and departureDay=?", new String[]{String.valueOf(year), String.valueOf(month), String.valueOf(day)}, null, null, "cost");
        List<ItineraryModel> itineraryModels = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                ItineraryModel model = new ItineraryModel();
                model.setId(cursor.getInt(cursor.getColumnIndex("id")));
                model.setFlightNumber(cursor.getInt(cursor.getColumnIndex("flightNumber")));
                model.setDepartureYear(cursor.getInt(cursor.getColumnIndex("departureYear")));
                model.setDepartureMonth(cursor.getInt(cursor.getColumnIndex("departureMonth")));
                model.setDepartureDay(cursor.getInt(cursor.getColumnIndex("departureDay")));
                model.setDepartureHour(cursor.getInt(cursor.getColumnIndex("departureHour")));
                model.setDepartureMinute(cursor.getInt(cursor.getColumnIndex("departureMinute")));
                model.setArrivalYear(cursor.getInt(cursor.getColumnIndex("arrivalYear")));
                model.setArrivalMonth(cursor.getInt(cursor.getColumnIndex("arrivalMonth")));
                model.setArrivalDay(cursor.getInt(cursor.getColumnIndex("arrivalDay")));
                model.setArrivalHour(cursor.getInt(cursor.getColumnIndex("arrivalHour")));
                model.setArrivalMinute(cursor.getInt(cursor.getColumnIndex("arrivalMinute")));
                model.setAirline(cursor.getString(cursor.getColumnIndex("airline")));
                model.setOrigin(cursor.getString(cursor.getColumnIndex("origin")));
                model.setDestination(cursor.getString(cursor.getColumnIndex("destination")));
                model.setCost(cursor.getDouble(cursor.getColumnIndex("cost")));
                model.setTravelHour(cursor.getInt(cursor.getColumnIndex("travellingHour")));
                model.setTravelMinute(cursor.getInt(cursor.getColumnIndex("travellingMinute")));
                itineraryModels.add(model);
            } while (cursor.moveToNext());

            return itineraryModels;
        }
        return new ArrayList<>();
    }

    public List<ItineraryModel> getItinerariesOrderByCost() {
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.query("Itinerary", new String[]{"id", "flightNumber", "departureYear", "departureMonth", "departureDay",
                "departureHour", "departureMinute", "arrivalYear", "arrivalMonth", "arrivalDay", "arrivalHour", "arrivalMinute", "airline", "origin",
                "destination", "cost", "travellingHour", "travellingMinute"}, null, null, null, null, "cost");
        List<ItineraryModel> itineraryModels = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                ItineraryModel model = new ItineraryModel();
                model.setId(cursor.getInt(cursor.getColumnIndex("id")));
                model.setFlightNumber(cursor.getInt(cursor.getColumnIndex("flightNumber")));
                model.setDepartureYear(cursor.getInt(cursor.getColumnIndex("departureYear")));
                model.setDepartureMonth(cursor.getInt(cursor.getColumnIndex("departureMonth")));
                model.setDepartureDay(cursor.getInt(cursor.getColumnIndex("departureDay")));
                model.setDepartureHour(cursor.getInt(cursor.getColumnIndex("departureHour")));
                model.setDepartureMinute(cursor.getInt(cursor.getColumnIndex("departureMinute")));
                model.setArrivalYear(cursor.getInt(cursor.getColumnIndex("arrivalYear")));
                model.setArrivalMonth(cursor.getInt(cursor.getColumnIndex("arrivalMonth")));
                model.setArrivalDay(cursor.getInt(cursor.getColumnIndex("arrivalDay")));
                model.setArrivalHour(cursor.getInt(cursor.getColumnIndex("arrivalHour")));
                model.setArrivalMinute(cursor.getInt(cursor.getColumnIndex("arrivalMinute")));
                model.setAirline(cursor.getString(cursor.getColumnIndex("airline")));
                model.setOrigin(cursor.getString(cursor.getColumnIndex("origin")));
                model.setDestination(cursor.getString(cursor.getColumnIndex("destination")));
                model.setCost(cursor.getDouble(cursor.getColumnIndex("cost")));
                model.setTravelHour(cursor.getInt(cursor.getColumnIndex("travellingHour")));
                model.setTravelMinute(cursor.getInt(cursor.getColumnIndex("travellingMinute")));
                itineraryModels.add(model);
            } while (cursor.moveToNext());

            return itineraryModels;
        }
        return null;
    }

    public ItineraryModel getItineraryById(int id) {
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.query("Itinerary", new String[]{"id", "flightNumber", "departureYear", "departureMonth", "departureDay",
                "departureHour", "departureMinute", "arrivalYear", "arrivalMonth", "arrivalDay", "arrivalHour", "arrivalMinute", "airline", "origin",
                "destination", "cost", "travellingHour", "travellingMinute"}, "id=?", new String[]{String.valueOf(id)}, null, null, "cost");
        List<ItineraryModel> itineraryModels = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                ItineraryModel model = new ItineraryModel();
                model.setId(cursor.getInt(cursor.getColumnIndex("id")));
                model.setFlightNumber(cursor.getInt(cursor.getColumnIndex("flightNumber")));
                model.setDepartureYear(cursor.getInt(cursor.getColumnIndex("departureYear")));
                model.setDepartureMonth(cursor.getInt(cursor.getColumnIndex("departureMonth")));
                model.setDepartureDay(cursor.getInt(cursor.getColumnIndex("departureDay")));
                model.setDepartureHour(cursor.getInt(cursor.getColumnIndex("departureHour")));
                model.setDepartureMinute(cursor.getInt(cursor.getColumnIndex("departureMinute")));
                model.setArrivalYear(cursor.getInt(cursor.getColumnIndex("arrivalYear")));
                model.setArrivalMonth(cursor.getInt(cursor.getColumnIndex("arrivalMonth")));
                model.setArrivalDay(cursor.getInt(cursor.getColumnIndex("arrivalDay")));
                model.setArrivalHour(cursor.getInt(cursor.getColumnIndex("arrivalHour")));
                model.setArrivalMinute(cursor.getInt(cursor.getColumnIndex("arrivalMinute")));
                model.setAirline(cursor.getString(cursor.getColumnIndex("airline")));
                model.setOrigin(cursor.getString(cursor.getColumnIndex("origin")));
                model.setDestination(cursor.getString(cursor.getColumnIndex("destination")));
                model.setCost(cursor.getDouble(cursor.getColumnIndex("cost")));
                model.setTravelHour(cursor.getInt(cursor.getColumnIndex("travellingHour")));
                model.setTravelMinute(cursor.getInt(cursor.getColumnIndex("travellingMinute")));
                itineraryModels.add(model);
            } while (cursor.moveToNext());

            return itineraryModels.get(0);
        }
        return null;
    }

    public boolean addBooking(BookingModel model) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("ItineraryId", model.getItineraryId());

        return database.insert("Booking", null, values) > 0;
    }

    public List<BookingModel> getBookings() {
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.query("Booking", new String[]{"id", "ItineraryId"}, null, null, null, null, null);
        List<BookingModel> bookingModels = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                BookingModel model = new BookingModel();
                model.setId(cursor.getInt(cursor.getColumnIndex("id")));
                model.setItineraryId(cursor.getInt(cursor.getColumnIndex("ItineraryId")));
                bookingModels.add(model);
            } while (cursor.moveToNext());

        }

        return bookingModels;
    }

    public boolean addPersonalInfo(PersonalInformationModel model) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", model.getName());
        values.put("address", model.getAddress());
        values.put("phoneNumber", model.getPhoneNumber());
        values.put("creditCardNumber", model.getCreditCardNumber());
        return database.insert("PersonalInformation", null, values) > 0;
    }
    public PersonalInformationModel getPersonalInfo(){
        SQLiteDatabase readableDatabase = this.getReadableDatabase();
        Cursor cursor=readableDatabase.query("PersonalInformation",new String[]{"id","name","address","phoneNumber","creditCardNumber"},null,null,null,null,null);
        PersonalInformationModel model=new PersonalInformationModel();
        if(cursor.moveToFirst()){
            do {
                model.setId(cursor.getInt(cursor.getColumnIndex("id")));
                model.setName(cursor.getString(cursor.getColumnIndex("name")));
                model.setAddress(cursor.getString(cursor.getColumnIndex("address")));
                model.setPhoneNumber(cursor.getString(cursor.getColumnIndex("phoneNumber")));
                model.setCreditCardNumber(cursor.getString(cursor.getColumnIndex("creditCardNumber")));
            }while (cursor.moveToNext());
            return model;
        }
        return model;

    }

    public void clearBooking() {
        SQLiteDatabase writableDatabase = this.getWritableDatabase();
        writableDatabase.delete("Booking",null,null);

    }
}
