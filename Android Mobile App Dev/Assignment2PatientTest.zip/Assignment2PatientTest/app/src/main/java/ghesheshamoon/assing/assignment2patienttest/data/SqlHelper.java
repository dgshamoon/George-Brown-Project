package ghesheshamoon.assing.assignment2patienttest.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

import ghesheshamoon.assing.assignment2patienttest.model.Doctor;
import ghesheshamoon.assing.assignment2patienttest.model.Nurse;
import ghesheshamoon.assing.assignment2patienttest.model.Patient;
import ghesheshamoon.assing.assignment2patienttest.model.Test;


public class SqlHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "MedicalDb";

    public SqlHelper(Context context) {
        super(context, DB_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "create table if not exists Doctor(" +
                "doctorId INTEGER primary key autoincrement," +
                "firstname text," +
                "lastname text," +
                "department text);";
        db.execSQL(query);
        query = "create table if not exists Nurse(" +
                "nurseId INTEGER primary key autoincrement," +
                "firstname text," +
                "lastname text," +
                "department text);";
        db.execSQL(query);
        query = "create table if not exists Patient(" +
                "patientId INTEGER primary key autoincrement," +
                "firstname text," +
                "lastname text," +
                "department text," +
                "doctorId INTEGER," +
                "room text," +
                "foreign key(doctorId) references doctor(doctorId));";
        db.execSQL(query);
        query = "create table if not exists Test(" +
                "testId INTEGER primary key autoincrement," +
                "patientId INTEGER," +
                "bpl real," +
                "bph real," +
                "temperture real," +
                "foreign key(patientId) references patient(patientId));";
        db.execSQL(query);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean addDoctor(Doctor doctor) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("firstname", doctor.getFirstname());
        values.put("lastname", doctor.getLastname());
        values.put("department", doctor.getDepartment());
        boolean result = database.insert("Doctor", null, values) > 0;

        database.close();
        return result;
    }

    public Doctor getDoctor(String firstname, String lastname) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("Doctor", new String[]{"doctorId", "firstname", "lastname", "department"}, "firstname=? and lastname=?", new String[]{firstname, lastname}, null, null, null);
        Doctor doctor = new Doctor();
        if (cursor.moveToFirst()) {
            doctor.setDoctorId(cursor.getInt(cursor.getColumnIndex("doctorId")));
            doctor.setFirstname(cursor.getString(cursor.getColumnIndex("firstname")));
            doctor.setFirstname(cursor.getString(cursor.getColumnIndex("lastname")));
            doctor.setFirstname(cursor.getString(cursor.getColumnIndex("department")));

        }
        cursor.close();
        db.close();
        return doctor;
    }

    public Doctor getDoctor(int doctorId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("Doctor", new String[]{"doctorId", "firstname", "lastname", "department"}, "doctorId=?", new String[]{doctorId + ""}, null, null, null);
        Doctor doctor = new Doctor();
        if (cursor.moveToFirst()) {
            doctor.setDoctorId(cursor.getInt(cursor.getColumnIndex("doctorId")));
            doctor.setFirstname(cursor.getString(cursor.getColumnIndex("firstname")));
            doctor.setLastname(cursor.getString(cursor.getColumnIndex("lastname")));
            doctor.setDepartment(cursor.getString(cursor.getColumnIndex("department")));

        }
        cursor.close();
        db.close();
        return doctor;
    }

    public List<Doctor> getDoctors() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("Doctor", new String[]{"doctorId", "firstname", "lastname", "department"}, null, null, null, null, null);
        Doctor doctor;
        List<Doctor> doctors = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                doctor = new Doctor();
                doctor.setDoctorId(cursor.getInt(cursor.getColumnIndex("doctorId")));
                doctor.setFirstname(cursor.getString(cursor.getColumnIndex("firstname")));
                doctor.setLastname(cursor.getString(cursor.getColumnIndex("lastname")));
                doctor.setDepartment(cursor.getString(cursor.getColumnIndex("department")));
                doctors.add(doctor);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return doctors;
    }

    public Nurse getNurse(String firstname, String lastname) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("Nurse", new String[]{"nurseId", "firstname", "lastname", "department"}, "firstname=? and lastname=?", new String[]{firstname, lastname}, null, null, null);
        Nurse nurse = new Nurse();
        if (cursor.moveToFirst()) {
            nurse.setNurseId(cursor.getInt(cursor.getColumnIndex("nurseId")));
            nurse.setFirstname(cursor.getString(cursor.getColumnIndex("firstname")));
            nurse.setFirstname(cursor.getString(cursor.getColumnIndex("lastname")));
            nurse.setFirstname(cursor.getString(cursor.getColumnIndex("department")));

        }
        cursor.close();
        db.close();
        return nurse;
    }

    public Nurse getNurse(int nurseId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("Nurse", new String[]{"nurseId", "firstname", "lastname", "department"}, "nurseId=? ", new String[]{nurseId + ""}, null, null, null);
        Nurse nurse = new Nurse();
        if (cursor.moveToFirst()) {
            nurse.setNurseId(cursor.getInt(cursor.getColumnIndex("nurseId")));
            nurse.setFirstname(cursor.getString(cursor.getColumnIndex("firstname")));
            nurse.setFirstname(cursor.getString(cursor.getColumnIndex("lastname")));
            nurse.setFirstname(cursor.getString(cursor.getColumnIndex("department")));

        }
        cursor.close();
        db.close();
        return nurse;
    }

    public boolean addNurse(Nurse nurse) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("firstname", nurse.getFirstname());
        values.put("lastname", nurse.getLastname());
        values.put("department", nurse.getDepartment());
        boolean result = database.insert("Nurse", null, values) > 0;

        database.close();
        return result;
    }

    public boolean addPatient(Patient patient) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("firstname", patient.getFirstname());
        values.put("lastname", patient.getLastname());
        values.put("department", patient.getDepartment());
        values.put("doctorId", patient.getDoctorId());
        values.put("room", patient.getRoom());
        boolean result = database.insert("Patient", null, values) > 0;
        database.close();
        return result;
    }

    public Patient getPatient(int patientId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("Patient", new String[]{"patientId", "firstname", "lastname", "department", "doctorId", "room"}, "patientId=?", new String[]{patientId + ""}, null, null, null);
        Patient patient = new Patient();
        if (cursor.moveToFirst()) {
            patient.setPatientId(cursor.getInt(cursor.getColumnIndex("patientId")));
            patient.setFirstname(cursor.getString(cursor.getColumnIndex("firstname")));
            patient.setLastname(cursor.getString(cursor.getColumnIndex("lastname")));
            patient.setDepartment(cursor.getString(cursor.getColumnIndex("department")));
            patient.setDoctorId(cursor.getInt(cursor.getColumnIndex("doctorId")));
            patient.setRoom(cursor.getString(cursor.getColumnIndex("room")));
        }
        cursor.close();
        db.close();
        return patient;
    }

    public List<Patient> getPatients() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("Patient", new String[]{"patientId", "firstname", "lastname", "department", "doctorId", "room"}, null, null, null, null, null);
        Patient patient;
        List<Patient> patients = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {


                patient = new Patient();
                patient.setPatientId(cursor.getInt(cursor.getColumnIndex("patientId")));
                patient.setFirstname(cursor.getString(cursor.getColumnIndex("firstname")));
                patient.setLastname(cursor.getString(cursor.getColumnIndex("lastname")));
                patient.setDepartment(cursor.getString(cursor.getColumnIndex("department")));
                patient.setDoctorId(cursor.getInt(cursor.getColumnIndex("doctorId")));
                patient.setRoom(cursor.getString(cursor.getColumnIndex("room")));
                patients.add(patient);

            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return patients;
    }
    public List<Test> getPatientTests(int patientId){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("Test", new String[]{"testId", "patientId", "bpl", "bph", "temperture"}, "patientId=?", new String[]{patientId+""}, null, null, null);
        Test test;
        List<Test> tests = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {


                test = new Test();
                test.setPatientId(cursor.getInt(cursor.getColumnIndex("patientId")));
                test.setTestId(cursor.getInt(cursor.getColumnIndex("testId")));
                test.setBpl(cursor.getFloat(cursor.getColumnIndex("bpl")));
                test.setBph(cursor.getFloat(cursor.getColumnIndex("bph")));
                test.setTemperture(cursor.getFloat(cursor.getColumnIndex("temperture")));
                tests.add(test);

            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return tests;
    }
    public boolean addTest(Test test) {
        ContentValues values = new ContentValues();
        values.put("patientId", test.getPatientId());
        values.put("bpl", test.getBpl());
        values.put("bph", test.getBph());
        values.put("temperture", test.getTemperture());
        SQLiteDatabase db = this.getWritableDatabase();
        boolean result = db.insert("Test", null, values) > 0;
        db.close();
        return result;
    }

    public Test getPatientTest(int testId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("Test", new String[]{"patientId", "testId", "temperture", "bpl", "bph"}, "testId=?", new String[]{testId + ""}, null, null, null);
        Test test = new Test();
        if (cursor.moveToFirst()) {
            test.setPatientId(cursor.getInt(cursor.getColumnIndex("patientId")));
            test.setTestId(cursor.getInt(cursor.getColumnIndex("testId")));
            test.setBph(cursor.getFloat(cursor.getColumnIndex("bph")));
            test.setBpl(cursor.getFloat(cursor.getColumnIndex("bpl")));
            test.setTemperture(cursor.getFloat(cursor.getColumnIndex("temperture")));
        }
        cursor.close();
        db.close();
        return test;
    }
}
