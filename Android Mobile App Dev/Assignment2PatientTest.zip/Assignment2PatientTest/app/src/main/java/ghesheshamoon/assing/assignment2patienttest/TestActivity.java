package ghesheshamoon.assing.assignment2patienttest;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import ghesheshamoon.assing.assignment2patienttest.data.SqlHelper;
import ghesheshamoon.assing.assignment2patienttest.model.Patient;
import ghesheshamoon.assing.assignment2patienttest.model.Test;

public class TestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        Intent intent=getIntent();
        final EditText bpltext= (EditText) findViewById(R.id.bplText);
        final EditText bphText= (EditText) findViewById(R.id.bphText);
        final EditText tempertureText= (EditText) findViewById(R.id.tempertureText);
        Button testBtn= (Button) findViewById(R.id.testBtn);
        TextView patientName = (TextView) findViewById(R.id.patientTVinTest);
        final SqlHelper helper=new SqlHelper(this);
        if(intent.hasExtra("type")){
            String tpe= intent.getStringExtra("type");

            if(tpe.equals("add")){
                int id=intent.getIntExtra("id",0);
                final Patient patient = helper.getPatient(id);
                Toast.makeText(this, patient.toString(), Toast.LENGTH_SHORT).show();
                patientName.setText(patient.getFirstname()+" "+patient.getLastname());
                testBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Test test=new Test();
                        test.setPatientId(patient.getPatientId());
                        test.setBpl(Float.parseFloat( bpltext.getText().toString()));
                        test.setBph(Float.parseFloat(bphText.getText().toString()));
                        test.setTemperture(Float.parseFloat(tempertureText.getText().toString()));
                        helper.addTest(test);
                        Toast.makeText(TestActivity.this, test.toString(), Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
            }
            else if(tpe.equals("view")){
                int id=intent.getIntExtra("patientId",0);
                Patient patient = helper.getPatient(id);
                
                int testId=intent.getIntExtra("id",0);
                Test test=helper.getPatientTest(testId);
                patientName.setText(patient.getFirstname()+" "+patient.getLastname());
                bpltext.setText(test.getBpl()+"");
                bphText.setText(test.getBph()+"");
                tempertureText.setText(test.getTemperture()+"");
                testBtn.setVisibility(View.GONE);
            }

        }
    }
}
