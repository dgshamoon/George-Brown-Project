package ghesheshamoon.assing.assignment2patienttest;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import ghesheshamoon.assing.assignment2patienttest.data.SqlHelper;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void loginDoctorOrNurse(View view) {
        RadioButton doctorRadio= (RadioButton) findViewById(R.id.doctorRadio);
        RadioButton nurseRadio= (RadioButton) findViewById(R.id.nurseRadio);
        EditText firstnameEdit= (EditText) findViewById(R.id.firstnameET);
        EditText lastnameEdit= (EditText) findViewById(R.id.lastnameET);
        if(!doctorRadio.isChecked()&& !nurseRadio.isChecked()){
            Toast.makeText(this, "who are you? select one job", Toast.LENGTH_SHORT).show();
            return;
        }
        if(firstnameEdit.getText().length()==0 || lastnameEdit.getText().length()==0){
            Toast.makeText(this, "Enter Both Firstname and lastname", Toast.LENGTH_SHORT).show();
            return;
        }
        SqlHelper helper = new SqlHelper(this);
        if(doctorRadio.isChecked()){
            if(helper.getDoctor(firstnameEdit.getText().toString(),lastnameEdit.getText().toString())!=null){
                startActivity(new Intent(MainActivity.this,PatientsActivity.class));
            }
            else {
                Toast.makeText(this, "Invalid firstname or lastnam", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        else if(nurseRadio.isChecked()){
            if(helper.getNurse(firstnameEdit.getText().toString(),lastnameEdit.getText().toString())!=null){
                startActivity(new Intent(MainActivity.this,PatientsActivity.class));
            }
            else {
                Toast.makeText(this, "Invalid firstname or lastnam", Toast.LENGTH_SHORT).show();
                return;
            }
        }
    }

    public void gotoRegister(View view) {
        startActivity(new Intent(MainActivity.this,RegiterActivity.class));
    }
}
