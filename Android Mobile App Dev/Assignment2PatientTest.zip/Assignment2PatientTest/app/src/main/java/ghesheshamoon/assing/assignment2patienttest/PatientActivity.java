package ghesheshamoon.assing.assignment2patienttest;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;

import ghesheshamoon.assing.assignment2patienttest.data.SqlHelper;
import ghesheshamoon.assing.assignment2patienttest.model.Doctor;
import ghesheshamoon.assing.assignment2patienttest.model.Patient;

public class PatientActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient);
        Intent intent = getIntent();
        final SqlHelper helper=new SqlHelper(this);
        final EditText patientFirstname= (EditText) findViewById(R.id.patientFirstname);
        final EditText patientLastname= (EditText) findViewById(R.id.patientLastname);
        final EditText patientDepartment= (EditText) findViewById(R.id.patientDepartment);
        final EditText patientRoom= (EditText) findViewById(R.id.patientRoom);
        final Spinner doctorSpinner= (Spinner) findViewById(R.id.doctorSpinner);
        List<Doctor> doctors = helper.getDoctors();
        final ArrayAdapter<Doctor> doctorAdapter=new ArrayAdapter<Doctor>(this,android.R.layout.simple_spinner_item,  doctors);
        doctorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        doctorSpinner.setAdapter(doctorAdapter);
        Button addPatientBtn= (Button) findViewById(R.id.patientButtonAction);
        if(intent.hasExtra("type")){
            if(intent.getStringExtra("type").equals("new")){
                addPatientBtn.setText("Add");
            }
            else if(intent.getStringExtra("type").equals("view")){
                int id=intent.getIntExtra("id",0);
                Patient patient = helper.getPatient(id);
                patientFirstname.setText(patient.getFirstname());
                patientLastname.setText(patient.getLastname());
                patientDepartment.setText(patient.getDepartment());
                patientRoom.setText(patient.getRoom());
                doctorSpinner.setVisibility(View.GONE);
                TextView doctorTextView= (TextView) findViewById(R.id.textView5);
                doctorTextView.setText("doctor: "+helper.getDoctor(patient.getDoctorId()).toString());
                addPatientBtn.setTag(patient);
                addPatientBtn.setText("Add Test");
            }
            addPatientBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(view.getTag()==null){    //add new patient
                        Patient patient = new Patient();
                        patient.setFirstname(patientFirstname.getText().toString());
                        patient.setLastname(patientLastname.getText().toString());
                        patient.setDepartment(patientDepartment.getText().toString());
                        patient.setRoom(patientRoom.getText().toString());
                        patient.setDoctorId(doctorAdapter.getItem(doctorSpinner.getSelectedItemPosition()).getDoctorId());
                        helper.addPatient(patient);
                        finish();
                    }
                    else{
                        Patient patient= (Patient) view.getTag();
                        Intent intent1=new Intent(PatientActivity.this,TestListActivity.class);
                        intent1.putExtra("id",patient.getPatientId());
                        startActivity(intent1);
                    }
                }
            });
        }
    }
}
