package ghesheshamoon.assing.assignment2patienttest.model;

public class Doctor {
    int doctorId;
    String firstname;
    String lastname;
    String department;

    public Doctor(String firstname, String lastname, String department) {
        this.firstname=firstname;
        this.lastname=lastname;
        this.department=department;
    }

    public Doctor() {

    }

    @Override
    public String toString() {
        return firstname+" "+lastname;
    }

    public int getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
}
