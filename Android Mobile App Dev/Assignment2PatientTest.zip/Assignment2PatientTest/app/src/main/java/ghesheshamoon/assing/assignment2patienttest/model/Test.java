package ghesheshamoon.assing.assignment2patienttest.model;


public class Test {
    int testId;
    int patientId;
    float bpl;
    float bph;
    float temperture;

    public int getTestId() {
        return testId;
    }

    @Override
    public String toString() {
        return "testid: "+testId+"\nbpl:"+bpl+"\nbph: "+bph+"\ntemp: "+temperture;
    }

    public void setTestId(int testId) {
        this.testId = testId;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public float getBpl() {
        return bpl;
    }

    public void setBpl(float bpl) {
        this.bpl = bpl;
    }

    public float getBph() {
        return bph;
    }

    public void setBph(float bph) {
        this.bph = bph;
    }

    public float getTemperture() {
        return temperture;
    }

    public void setTemperture(float temperture) {
        this.temperture = temperture;
    }
}
