package ghesheshamoon.assing.assignment2patienttest.model;



public class Patient {
    int patientId;
    String firstname;
    String lastname;
    String department;
    int doctorId;
    String room;

    @Override
    public String toString() {
        return "patient Id: "+patientId+"\nfirstname: "+ firstname+"\nlastname: "+lastname+"\ndepartment: "+department+"\nRoom: "+room+"\nDoctorId: "+doctorId;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }
}
