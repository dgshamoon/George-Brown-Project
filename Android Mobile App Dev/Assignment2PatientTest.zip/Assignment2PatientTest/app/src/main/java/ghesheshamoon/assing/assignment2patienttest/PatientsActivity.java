package ghesheshamoon.assing.assignment2patienttest;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.List;

import ghesheshamoon.assing.assignment2patienttest.data.SqlHelper;
import ghesheshamoon.assing.assignment2patienttest.model.Patient;

public class PatientsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patients);
        SqlHelper helper = new SqlHelper(this);
        final List<Patient> patients = helper.getPatients();
        ArrayAdapter<Patient> adapter = new ArrayAdapter<Patient>(this, android.R.layout.simple_list_item_1,  patients);
        ListView listView = (ListView) findViewById(R.id.patientsList);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Patient patient = patients.get(position);
                Intent intent=new Intent(PatientsActivity.this,PatientActivity.class);
                intent.putExtra("type","view");
                intent.putExtra("id",patient.getPatientId());
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem newPatient = menu.add(0, 1001, 1, "Add Patient");
        newPatient.setIcon(android.R.drawable.ic_menu_add);
        newPatient.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        newPatient.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Intent intent = new Intent(PatientsActivity.this, PatientActivity.class);
                intent.putExtra("type","new");
                startActivity(intent);
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }
}
