package ghesheshamoon.assing.assignment2patienttest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import ghesheshamoon.assing.assignment2patienttest.data.SqlHelper;
import ghesheshamoon.assing.assignment2patienttest.model.Doctor;
import ghesheshamoon.assing.assignment2patienttest.model.Nurse;

public class RegiterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regiter);
    }

    public void cancelRegister(View view) {
        finish();
    }

    public void registerPerson(View view) {
        RadioButton doctorRadio= (RadioButton) findViewById(R.id.doctorRadioR);
        RadioButton nurseRadio= (RadioButton) findViewById(R.id.nurseRadioR);
        EditText firstnameText= (EditText) findViewById(R.id.firstnameETR);
        EditText lastnameText= (EditText) findViewById(R.id.lastnameETR);
        EditText department= (EditText) findViewById(R.id.departmentTER);
        if(!doctorRadio.isChecked()&& !nurseRadio.isChecked()){
            Toast.makeText(this, "who are you? select one job", Toast.LENGTH_SHORT).show();
            return;
        }
        if(firstnameText.getText().length()==0 || lastnameText.getText().length()==0|| department.getText().length()==0){
            Toast.makeText(this, "Enter all data ", Toast.LENGTH_SHORT).show();
            return;
        }
        SqlHelper helper = new SqlHelper(this);
        if(doctorRadio.isChecked()){

            Doctor doctor = new Doctor(firstnameText.getText().toString(), lastnameText.getText().toString(), department.getText().toString());
            helper.addDoctor(doctor);
            Toast.makeText(this, doctor.toString()+" Registerd Successfully", Toast.LENGTH_SHORT).show();
        }
        else if(nurseRadio.isChecked()){
            Nurse nurse = new Nurse(firstnameText.getText().toString(), lastnameText.getText().toString(), department.getText().toString());
            helper.addNurse(nurse);
            Toast.makeText(this, nurse.toString()+" Registerd Successfully", Toast.LENGTH_SHORT).show();
        }

        finish();
    }
}
