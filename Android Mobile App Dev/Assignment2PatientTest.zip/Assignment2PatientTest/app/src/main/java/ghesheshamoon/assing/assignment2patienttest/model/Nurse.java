package ghesheshamoon.assing.assignment2patienttest.model;

public class Nurse {
    int nurseId;
    String firstname;
    String lastname;
    String department;

    public Nurse(String firstname, String lastname, String department) {
        this.firstname=firstname;
        this.lastname=lastname;
        this.department=department;
    }

    public Nurse() {

    }

    public int getNurseId() {
        return nurseId;
    }

    public void setNurseId(int nurseId) {
        this.nurseId = nurseId;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
}
