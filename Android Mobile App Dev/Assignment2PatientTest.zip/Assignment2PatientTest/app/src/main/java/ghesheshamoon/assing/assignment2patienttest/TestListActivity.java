package ghesheshamoon.assing.assignment2patienttest;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

import ghesheshamoon.assing.assignment2patienttest.data.SqlHelper;
import ghesheshamoon.assing.assignment2patienttest.model.Test;

public class TestListActivity extends AppCompatActivity {
Intent intent;
    int patientId=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_list);
        ListView testList= (ListView) findViewById(R.id.testList);
        SqlHelper helper=new SqlHelper(this);
         intent=getIntent();

        if(intent.hasExtra("id")){

            patientId=intent.getIntExtra("id",0);
            List<Test> tests = helper.getPatientTests(patientId);
            final ArrayAdapter<Test> testArrayAdapter=new ArrayAdapter<Test>(TestListActivity.this,android.R.layout.simple_list_item_1,tests);
            testList.setAdapter(testArrayAdapter);
            testList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    Test item = testArrayAdapter.getItem(i);
                    Intent intent1=new Intent(TestListActivity.this,TestActivity.class);
                    intent1.putExtra("type","view");
                    intent1.putExtra("patientId",patientId);
                    intent1.putExtra("id",item.getTestId());
                    startActivity(intent1);
                }
            });
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem addItem = menu.add(0, 100, 1, "add");
        addItem.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        addItem.setIcon(android.R.drawable.ic_menu_add);
        addItem.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                Intent intent=new Intent(TestListActivity.this,TestActivity.class);
                intent.putExtra("type","add");

                intent.putExtra("id",patientId);
                startActivity(intent);
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }
}
